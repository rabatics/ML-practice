function graph(X, y)


m = length(y);
plot(X, y, 'rx', 'MarkerSize', 10); 
ylabel('Profit in Million $'); 
xlabel('Population in 100000s ');

end
